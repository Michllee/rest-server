# Nodejs-简介


## 同步与异步

--------------------------------------------
### 1.同步
同步可以理解为一步接着一步，直达完成当前所有步骤。<br>

举个餐馆订餐的例子：<br>
（1）小明去餐馆排队点餐，队伍排到小明，小明下单，店主接单<br>
（2）厨师做菜，小明依旧在队头等待，店主也在等待。<br>
（3）厨师完成菜品交给店主，店主交给小明，完成此单<br>
（4）店主接下一单。<br>


javascript:
```javascript
console.log("ajax start");
$.ajax({
    url:"//www.baidu.com/api/xxxx",
    type:"post",
    dataType:"json",
    async:false,
    success:function(r){
        console.log("ajax success");
    }
})

console.log("ajax end");
```
![](./ajax-synchronous.jpg)
******************************
### 2.异步
异步理解为完成部分操作后，继续下一项任务，当任务完成后发出通知继续执行第一项任务。<br>

依旧使用小明的例子：<br>
（1）小明去电话餐馆点餐，小明下单，店主接单<br>
（2）小明离开电话（do every thing he want）。店主继续接单，厨师做菜。<br>
（3）厨师完成菜品交给店主，店主电话通知小明，小明取餐。<br>

javascript:
```javascript
console.log("ajax start");
$.ajax({
    url:"//www.baidu.com/api/xxxx",
    type:"post",
    dataType:"json",
    success:function(r){
        console.log("ajax success");
    }
})

console.log("ajax end");
```
![](./ajax-asynchronus.jpg)

从上述两个例子可以基本看出同步相当于一次只专注一件事，异步反而三心二意了。但对计算机而言三心二意可能意味着完成的任务更多。<br>

--------------------------------------

## 异步编程
javascript 单线程










